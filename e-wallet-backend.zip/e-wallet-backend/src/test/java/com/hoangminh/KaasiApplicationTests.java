package com.hoangminh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaasiApplicationTests {

	@Test
	void contextLoads() {
	}

}
