package com.hoangminh.converter;

import com.hoangminh.dto.CustomerDTO;
import com.hoangminh.entity.CustomerEntity;
import org.springframework.stereotype.Component;

@Component
public class CustomerConverter {

    public CustomerEntity toEntity(CustomerDTO dto){
        CustomerEntity entity = new CustomerEntity();
        entity.setLastName(dto.getLastName());
        entity.setFirstName(dto.getFirstName());
        entity.setDateOfBirth(dto.getDateOfBirth());
        entity.setEmail(dto.getEmail());
        entity.setNationality(dto.getNationality());
        entity.setAddress(dto.getAddress());
        return entity;
    }

    public CustomerDTO toDTO(CustomerEntity entity){
        CustomerDTO dto = new CustomerDTO();
        if(entity.getId() != null){
            dto.setId(entity.getId());
        }
        dto.setLastName(entity.getLastName());
        dto.setFirstName(entity.getFirstName());
        dto.setDateOfBirth(entity.getDateOfBirth());
        dto.setEmail(entity.getEmail());
        dto.setNationality(entity.getNationality());
        dto.setAddress(entity.getAddress());
        dto.setBalance(entity.getBalance());
        dto.setUsername(entity.getUsername());
        dto.setRoles(entity.getRoles());
        return dto;
    }

    public CustomerEntity toEntity(CustomerDTO dto, CustomerEntity entity) {
        entity.setLastName(dto.getLastName());
        entity.setFirstName(dto.getFirstName());
        entity.setDateOfBirth(dto.getDateOfBirth());
        entity.setEmail(dto.getEmail());
        entity.setNationality(dto.getNationality());
        entity.setAddress(dto.getAddress());
        return entity;
    }
}
