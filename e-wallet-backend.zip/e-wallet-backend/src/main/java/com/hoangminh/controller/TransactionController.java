package com.hoangminh.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hoangminh.entity.Transaction;
import com.hoangminh.exception.UnknownException;
import com.hoangminh.service.ITransactionService;

@RestController
@RequestMapping("/api/transaction")
public class TransactionController {

	private static Logger logger = Logger.getLogger(TransactionController.class);

    @Autowired
    private ITransactionService transactionService;
    
	@GetMapping
	public ResponseEntity<List<Transaction>> getAllTransactionCategory(){
		try{
            logger.info("Success!");
            return new ResponseEntity<List<Transaction>>(transactionService.geTransactions(),HttpStatus.OK);
        } catch (Exception exc) {
            logger.error(exc);
            throw new UnknownException("Unknown Error");
        }
	}
}
