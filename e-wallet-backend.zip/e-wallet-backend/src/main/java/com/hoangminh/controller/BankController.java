package com.hoangminh.controller;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hoangminh.service.impl.BaoKimJWT;

import org.apache.commons.codec.binary.Base64;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/bank")
public class BankController {
	
	@Autowired
	private BaoKimJWT baoKimJWT;
	
	private final String apikey = "a18ff78e7a9e44f38de372e093d87ca1";
	private final String sec = "9623ac03057e433f95d86cf4f3bef5cc";

	
	private int jwtExpirationMs = 60;
	
	@GetMapping
	public String getPostResponse(){
        String uriString = "https://api.baokim.vn/payment/api/v4/bpm/list";
        RestTemplate restTemplate = new RestTemplate();
        String resString = restTemplate.getForObject(uriString, String.class);
        return resString;
    }
	
	@GetMapping("/list")
	public String getbank() throws InvalidKeyException, JsonProcessingException, NoSuchAlgorithmException{
		//String jwtString = generatetoken();
        String uriString = "https://sandbox-api.baokim.vn/payment/api/v4/bank/list?jwt="+baoKimJWT.generateToken();
        RestTemplate restTemplate = new RestTemplate();
        String resString = restTemplate.getForObject(uriString, String.class);
        return resString;
    }
	
	@PostMapping("/topup")
	public ResponseEntity<String> topup() throws InvalidKeyException, JsonProcessingException, NoSuchAlgorithmException{
		//String jwtString = generatetoken();
//		"amount": 17,
//        "card_id": 2,
//        "fee_amount": 9,
//        "bank_fee_amount": 4
        String uriString = "https://sandbox-api.baokim.vn/payment/api/v4/linked-wallet/topup-wallet?jwt="+baoKimJWT.generateToken();
        RestTemplate restTemplate = new RestTemplate();
        Map<String, Object> params = new HashMap<String, Object>();
        //Map<String, Object> params = new HashMap<String, Object>();
        params.put("amount", 17);
        params.put("card_id", 2);
        params.put("fee_amount", 9);
        params.put("bank_fee_amount", 4);
        
        ResponseEntity<String> resString = restTemplate.postForEntity(uriString, params, String.class);
        return resString;
    }
	
	@GetMapping("/token")
	public String gettoken() throws InvalidKeyException, JsonProcessingException, NoSuchAlgorithmException {
		return baoKimJWT.generateToken();
	}
	
	public String generatetoken() {
		byte[] b = new byte[32];
		SecureRandom random = new SecureRandom();
		random.nextBytes(b);
		String tokenId = bytesToHex(b);
		Base64 base64 = new Base64();
		tokenId = new String(base64.encode(tokenId.getBytes()));
		
		Date issuedAt = new Date();
		
		String jwt = Jwts.builder()
				.setId(tokenId)
				.setIssuer(apikey)
				.setIssuedAt(issuedAt)
				.setNotBefore(issuedAt)
				
				.setExpiration(new Date((new Date()).getTime() + jwtExpirationMs))
				.signWith(SignatureAlgorithm.HS256, sec).compact();
		
		return jwt;
	}
	
	public static String bytesToHex(byte[] bytes) {
	    final char[] hexArray = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	    char[] hexChars = new char[bytes.length * 2];
	    int v;
	    for ( int j = 0; j < bytes.length; j++ ) {
	        v = bytes[j] & 0xFF;
	        hexChars[j * 2] = hexArray[v >>> 4];
	        hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	    }
	    return new String(hexChars);
	}
}
