package com.hoangminh.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hoangminh.entity.BillInfo;

public interface BillinfoRepository extends JpaRepository<BillInfo, Long>{

}
