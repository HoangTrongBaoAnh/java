package com.hoangminh.repository;

import com.hoangminh.entity.CustomerEntity;
import com.hoangminh.dto.TransactionDTO;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CustomerRepository extends JpaRepository<CustomerEntity, Long> {
	Optional<CustomerEntity> findByUsername(String username);

	boolean existsByUsername(String username);

	boolean existsByEmail(String email);
	
	List<CustomerEntity> findByUsernameContaining(String title);
	
	@Query(value = "select DISTINCT MONTH(transactions.created_date) as transcmonth,transactions.*,name as category from transactions, customer, transaction_categories WHERE customer.id=transactions.customer_id and transaction_categories.id=trans_category_id and customer_id= :id order by transactions.created_date DESC",nativeQuery=true)
	Page<TransactionDTO> findallTransactions(@Param("id") long id,Pageable pageable);
}
