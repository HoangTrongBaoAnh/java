package com.hoangminh.service;

import java.util.List;

import com.hoangminh.entity.TransactionCategory;

public interface ITransactionCategoryService {
	List<TransactionCategory> geTransactionCategories();
}
