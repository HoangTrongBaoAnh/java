package com.hoangminh.service;

import java.util.List;

import com.hoangminh.entity.Transaction;

public interface ITransactionService {
	List<Transaction> geTransactions();
}
